# Muhammad Reyvan — Personal Portfolio

Website portfolio responsif berbasis HTML, CSS, dan JavaScript kecil untuk menu mobile serta tahun footer.

## Isi folder
- `index.html` — struktur dan isi halaman. Edit nama, teks, akademik, proyek, hobi, dan kontak di sini.
- `style.css` — seluruh gaya, layout, warna, dan breakpoint responsif.
- `assets/reyvan-profile.jpeg` — foto profil yang diberikan.

## Menjalankan lewat VS Code Live Server
1. Ekstrak ZIP ini ke folder yang mudah ditemukan.
2. Buka VS Code → **File → Open Folder** → pilih folder `muhammad_reyvan_portfolio`.
3. Jika belum ada, pasang ekstensi **Live Server** dari Extensions.
4. Klik kanan `index.html` → **Open with Live Server**.
5. Browser akan terbuka otomatis. Simpan file setelah diedit; Live Server akan memuat ulang halaman.

## Mengedit konten
- Profil, NIM, pendidikan, proyek, minat, dan kontak: cari teks terkait di `index.html`.
- Warna utama: edit variabel `--bg`, `--blue`, `--cyan`, dan `--violet` di awal `style.css`.
- Foto: ganti `assets/reyvan-profile.jpeg` dengan foto lain, lalu pertahankan nama file atau ubah path pada tag `<img>`.
- Kontak: ganti `email-kamu@example.com`, `@username-kamu`, dan tautan `#` dengan data asli.
- Video: letakkan video di `assets/profile-video.mp4`, lalu ganti blok `.video-placeholder` di `index.html` dengan:
  `<video controls playsinline preload="metadata" poster="assets/reyvan-profile.jpeg"><source src="assets/profile-video.mp4" type="video/mp4">Browser Anda tidak mendukung video.</video>`
  Tambahkan CSS `video { width: 100%; height: 100%; object-fit: cover; }` agar tampil memenuhi area.

## Catatan data
NIM, program studi, kampus, dan nama berasal dari informasi yang diberikan. IPK, semester, tahun masuk, prestasi, email, akun sosial, serta proyek lain tidak dikarang; bagian yang belum diketahui ditandai sebagai placeholder atau catatan untuk diedit.
